#**********************************#
# ███████╗ █████╗ ██╗  ██╗██╗  ██╗ #
# ██╔════╝██╔══██╗██║  ██║██║  ██║ #
# █████╗  ███████║███████║███████║ #
# ██╔══╝  ██╔══██║██╔══██║██╔══██║ #
# ██║     ██║  ██║██║  ██║██║  ██║ #
# ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ #
#**********************************#
# FrozenFried                      #
# Github - Frozen-Fried/fahh       #
#**********************************#

@tool
extends EditorPlugin

var sound_player : AudioStreamPlayer = AudioStreamPlayer.new()
var poll_timer = Timer.new()
var IS_PLAYING:bool = false
var DO_NOT_DISTURB:bool = false

var log_file_path


#Fahh - These are mp3
var FAHH_HUGE:AudioStream = load("res://addons/fahh/sounds/fahh/fahh_huge.mp3")
var FAHH_MID:AudioStream = load("res://addons/fahh/sounds/fahh/fahh_mid.mp3")
var FAHH_SMALL:AudioStream = load("res://addons/fahh/sounds/fahh/fahh_small.mp3")
var yelled:bool = false

func _ready() -> void:
	log_file_path = OS.get_user_data_dir()
	
func _enter_tree() -> void:
	
	if !DO_NOT_DISTURB:
		print("Fahh started!")
	#init the timer
	add_child(poll_timer)
	add_child(sound_player)
	sound_player.bus = "Master"
	
	poll_timer.wait_time = 1.0
	poll_timer.one_shot = false
	poll_timer.autostart = false

	poll_timer.timeout.connect(read_log)

	set_process(true)

func _process(_delta: float) -> void:
	var is_currently_playing = EditorInterface.is_playing_scene()

	# Started playing the game :)
	if is_currently_playing and !IS_PLAYING:
		IS_PLAYING = true
		if !DO_NOT_DISTURB:
			print("Game started")
		poll_timer.start()

	# Stopped playing the game :(
	elif !is_currently_playing and IS_PLAYING:
		IS_PLAYING = false
		if !DO_NOT_DISTURB:
			print("Game stopped")
			FahhPlayer.played = false
		poll_timer.stop()

func read_log():
	var log_dir = OS.get_user_data_dir() + "/logs"
	var bat_path = ProjectSettings.globalize_path(
		"res://addons/fahh/batch_file/read.bat"#batch files are not a thing that i understand,i used LLM xD
	)
	var args = ["/c",bat_path,log_dir]
	var output = []
	var exit_code = OS.execute("cmd.exe",args,output,true)
	#Now we read it!
	if FileAccess.file_exists(str(log_dir+"/godot_fahh.txt")):
		#read and do the thing
		#print(log_file_path + "/logs/godot_fahh.txt") #yeah,it works lol
		
		#SUIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
		var file_to_read = FileAccess.open(str(log_file_path + "/logs/godot_fahh.txt"),FileAccess.READ)
		var log = file_to_read.get_as_text()
		
		fahh(log)#NOW WE FAHHH
		 
func fahh(log:String):
	var error_count := log.count("SCRIPT ERROR:")
	print(error_count)
	if error_count > 0 and error_count < 3:
		FahhPlayer.play_("LOW")

	elif error_count >= 3 and error_count < 7:
		FahhPlayer.play_("MID")

	elif error_count >= 7:
		FahhPlayer.play_("HUGE")
#THIS DOESN"T WORK,GOTTA MANNUALY SET IT UP
func _enable_plugin() -> void:
	add_autoload_singleton("FahhPlayer","res://addons/fahh/fahh_player.tscn")
