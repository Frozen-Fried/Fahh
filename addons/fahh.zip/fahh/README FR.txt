Just enable the plugin and manually add the Fahh_player.tscn in the global with the name FahhPlayer.And go to your project settings and search for file logging,do these:
1.Enable File Logging,
2.Set the Max Log Files to 1,
That's it : )

*I ain't responsible for any unwanted damage to your computer or project : )

Thanks