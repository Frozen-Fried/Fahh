#**********************************#
# ███████╗ █████╗ ██╗  ██╗██╗  ██╗ #
# ██╔════╝██╔══██╗██║  ██║██║  ██║ #
# █████╗  ███████║███████║███████║ #
# ██╔══╝  ██╔══██║██╔══██║██╔══██║ #
# ██║     ██║  ██║██║  ██║██║  ██║ #
# ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ #
#**********************************#
# FrozenFried                      #
# Github - Frozen-Fried/fahh       #
#**********************************#

@tool
extends Node

@onready var stream_player: AudioStreamPlayer = $AudioStreamPlayer
var played:bool = false

#plays the sound 
func play_(strength:String):
	if played == false:
		match strength:
			"LOW":
				stream_player.bus = "Master"
				stream_player.stream = load("res://addons/fahh/sounds/fahh/fahh_small.mp3")
				stream_player.play()
				played = true
			"MID":
				stream_player.bus = "Master"
				stream_player.stream = load("res://addons/fahh/sounds/fahh/fahh_mid.mp3")
				stream_player.play()
				played = true
			"HUGE":
				stream_player.bus = "Master"
				stream_player.stream = load("res://addons/fahh/sounds/fahh/fahh_huge.mp3")
				stream_player.play()
				played = true

func pew():
	print("PEW")
